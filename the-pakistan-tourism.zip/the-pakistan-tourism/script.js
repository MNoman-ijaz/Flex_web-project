// Add animations or interactivity here
document.addEventListener('DOMContentLoaded', () => {
    // Example: Add a smooth scroll effect for navigation links
    document.querySelectorAll('.nav-links a').forEach(anchor => {
      anchor.addEventListener('click', function (e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
          behavior: 'smooth'
        });
      });
    });
  });